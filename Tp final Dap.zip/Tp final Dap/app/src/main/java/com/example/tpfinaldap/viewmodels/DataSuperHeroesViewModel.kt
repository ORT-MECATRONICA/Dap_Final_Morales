package com.example.tpfinaldap.viewmodels

import androidx.lifecycle.ViewModel

class DataSuperHeroesViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}